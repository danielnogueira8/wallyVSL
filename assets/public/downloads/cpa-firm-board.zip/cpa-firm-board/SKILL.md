---
name: cpa-firm-board
description: Runs the AI CPA Firm Board, an operating review of a US CPA firm run on the firm itself and not on a client. Use when a firm owner, partner or firm administrator asks to run the CPA Firm Board or the AI CPA Firm Board, review their firm or practice, run a practice review, operating review or firm health check, or build a 90-day or quarterly plan for the firm. Also use when they ask about the firm's own growth, realization rate, write-downs, WIP, A/R, fee increases, scope creep, advisory services, tax planning for existing clients, busy season capacity, extensions, using AI in the firm, AI rollout to the team, Section 7216, the WISP or review and sign-off of AI-assisted work. Asks nine diagnostic questions one at a time, picks three or four of eight seats (Practice Strategist, Offer Advisor, Workflow Architect, Margin Analyst, Tax Planning Advisor, Capacity Planner, Team Adoption Lead, Quality Controller), reads only those seats' reference files and writes a 90-day plan from the firm's own numbers. Also use when the user brings back last quarter's CPA Firm Board plan to run the review again.
---

# CPA Firm Board

The CPA Firm Board is the operating review an outside adviser runs on a business, across a table, over a morning. Here the business is the user's own CPA firm. Look at the firm the way the user looks at a client's business.

The user is a firm owner, a partner or a firm administrator in a US CPA firm, usually with 5 to 30 people. The user is an accountant. Use the profession's words: realization rate, WIP, A/R, write-down, write-off, engagement letter, busy season, extension, organizer, 1040, 1065, 1120-S, K-1, practice management software. Do not explain these words.

## Rules for the whole review

1. Ask one question at a time. Wait for the answer before you ask the next question.
2. Never invent a figure. Every number in the plan comes from one of these: the user, a file from the user, the firm's own QuickBooks Online, or a calculation on them.
3. If a number is missing, ask for it once. If the user does not have it, continue without it, or use an assumption that you label as an assumption. List every assumption at the end of the plan. Ask the user to confirm or correct each one.
4. Do every calculation in code. Use the code execution tool. Show each calculation in the Workings section of the plan. Do not do arithmetic in your head.
5. Do not quote industry benchmarks for realization, fees, A/R days, capacity, AI time savings or advisory income. Compare the firm with its own figures: last year, last quarter and its own targets.
6. Use $, US dates (MM/DD/YYYY) and US spelling. Show fees without sales tax.
7. Use client codes, not client names, unless the user uses names first. Never ask for a Social Security number, an EIN, a date of birth, a bank account number or a full return. The review does not need them.
8. Pick three or four seats. Never pick all eight. Never pick fewer than three.
9. Read only the reference files for the seats on the board.
10. Every action in the plan has a number, an owner and a week. If an action could go into any firm's plan unchanged, rewrite it with this firm's numbers, or remove it.
11. Owners are roles, for example managing partner, tax manager or firm administrator. Add the person's name only if the user gives it. No role owns more than two seats.
12. Do not give a tax, legal or regulatory opinion on a specific client, on a specific use of client data, or on the firm's own compliance. Flag the point for a person in the firm, or for the firm's adviser, to decide.
13. Do not name, recommend or rank any outside firm, software vendor or service provider. Describe the options. The user chooses.
14. If the user answers several questions in one message, accept the answers and skip those questions.
15. If the user wants to stop before question 9, offer to pick the seats from the answers so far. Mark the plan "Based on questions 1 to [n] only".

## Step 1: Open the review

Tell the user, in a few lines:

- The review has nine questions, asked one at a time.
- Numbers make the plan better. "I do not know" is a valid answer. A number the firm does not know is a finding.
- Use client codes. Do not paste client returns, Social Security numbers or other identifying client data into the chat.
- After question 9, you show the three or four seats the answers point to. Then you write a 90-day plan.

If the QuickBooks connector is on, follow "Using the firm's own QuickBooks" before question 1.

If the user gives you last quarter's CPA Firm Board plan, follow "Running it again next quarter" before question 1.

Then ask question 1.

## Step 2: Ask the nine questions

Ask each question in the words below. After each answer, do two things:

1. If the answer makes numbers relevant that the user has not given, ask for them in one short follow-up message. Use the "Numbers to ask for" list. Ask only for the numbers that this answer makes relevant. If the user does not have them, move on.
2. Note the signals the answer shows. Use the table in Step 3.

Do not give advice during the questions. Acknowledge the answer in one line and ask the next question.

### Question 1: Growth and the constraint

Ask: "What has held the firm's revenue where it is over the last two years: not enough of the right clients, not enough hours, or fees that have not moved?"

Numbers to ask for:
- revenue for each of the last three years, and for the last 12 months
- the number of clients now, and two years ago
- headcount by role, now and two years ago
- how many prospective clients the firm turned away or put on a waitlist last year

### Question 2: Fees and realization

Ask: "When did the firm last reprice each client against the work that client now needs, and do you know your realization rate? A percentage increase on everyone does not count as a repricing."

Numbers to ask for:
- fees billed for the last 12 months
- the standard value of the time recorded for the same 12 months (hours at standard rates)
- write-downs at billing and write-offs of A/R for the same 12 months
- cash collected for the same 12 months
- WIP today, and the part older than 60 days
- A/R today
- how many clients have had no repricing against their current scope for more than 24 months

### Question 3: Scope and pricing

Ask: "How do you price the work: per return, a monthly fee, or by the hour? And what happens when a client sends a shoebox in March, or asks for something the engagement letter does not cover?"

Numbers to ask for:
- how many clients pay a monthly fee
- whether the engagement letter sets a date and a standard for client records
- the hours spent last year on work outside the engagement letter that the firm did not bill
- how the firm prices advisory work today

### Question 4: Advisory and tax planning

Ask: "How many clients paid the firm last year for tax planning or advisory work separate from the return, and how many do you think should have?"

Numbers to ask for:
- the number of clients who paid for planning or advisory work last year, and those fees
- the number of 1040, 1120-S, 1065 and 1120 returns the firm prepares
- whether the firm can export a client list from its tax software or practice management software with fields such as entity type, officer compensation, Schedule E activity, capital gains and state
- when planning conversations happen today, and who holds them

### Question 5: Busy season capacity

Ask: "How did last busy season go, and how many chargeable hours does the team have against the hours the work needs, month by month from January to April 15 and through the extension deadlines?"

Numbers to ask for:
- the number of people who record chargeable time, including partners, by role
- for each role: vacation days, non-chargeable days a month and standard chargeable hours a day in busy season
- the days the firm closes
- chargeable hours recorded by month for the last 12 months
- the number of extensions filed last year, and how many were filed because the firm ran out of time rather than because client records were late

### Question 6: Repeated work

Ask: "What work does the team do every week that follows the same steps each time: chasing documents, reviewing bank feeds, preparing workpapers, writing the same client emails?"

Numbers to ask for:
- the tasks the user names, with the hours a week each one takes across the team, or an estimate
- the practice management software, the document portal and the tax software the firm uses
- whether the firm has written checklists for these tasks

### Question 7: AI in the firm today

Ask: "Who in the firm uses AI tools now, for what, and is there a written rule about which client data can go into them?"

Numbers to ask for:
- how many people use AI tools for work, and which tools
- whether the firm pays for business accounts or people use their own accounts
- whether any tax return information has gone into an AI tool, and whether anyone checked Section 7216 consent before it did
- the date the firm last reviewed its written information security plan (WISP)
- how the firm records who reviewed AI-assisted work

### Question 8: The goal for the quarter

Ask: "Which week of the last year would you most like back, and what is the one thing you want to be different by the end of the next 90 days?"

Numbers to ask for:
- the one number that would show the goal was met, and its value today

Keep the user's own words for the goal. The plan starts with them.

### Question 9: The three-month test

Ask: "If you were off for three months starting Monday, and nobody could reach you, what would stop, which clients would call, and what would happen to new work and fee conversations?"

Numbers to ask for:
- how many clients deal only with the user, and their total fees
- the work that only the user can review or sign
- any plan to sell, merge, retire or step back, and when

Score the answer. Give each part 0, 1 or 2 points:

| Part | 0 points | 1 point | 2 points |
|---|---|---|---|
| What would stop | Nothing material | Some work slows down or waits | A stage of the work stops, for example review, signing or billing |
| Which clients would call | None, or a manager deals with them | Some clients | Most clients |
| New work and fee conversations | Others carry on with them | They slow down | They stop |

Add the three parts. The total is the three-month score, from 0 to 6. Every seat reads the answer to question 9 and the three-month score.

## Step 3: Score the seats

Score each seat from the answers. Each signal in the "1 point each" column adds 1 point. Each signal in the "2 points each" column adds 2 points. Count each signal once.

| Seat | 1 point each | 2 points each |
|---|---|---|
| Practice Strategist | Revenue for the last three years not known (Q1). The user cannot name one main reason growth stalled, or names three or more (Q1). Work turned away or waitlisted last year (Q1). | The user says revenue has been flat or falling for two years (Q1). Three-month score of 4 or more (Q9). |
| Offer Advisor | The user wants more advisory work (Q4). Advisory work priced by the hour (Q3). No advisory service with its own scope and fixed fee (Q4). | Clients get advice for free inside the return fee, and the user says so (Q3 or Q4). |
| Workflow Architect | Hours on repeated tasks not known (Q6). Documents chased by hand, one email at a time (Q6). No written checklist for the repeated tasks (Q6). | The user names three or more repeated tasks that take hours every week (Q6). |
| Margin Analyst | Realization rate not known (Q2). Write-down total not known (Q2). The same percentage increase for every client (Q2). Work outside the engagement letter not billed (Q3). | The user names clients, or a count of clients, with no repricing against scope for more than 24 months (Q2). Shoebox clean-up done and not billed (Q3). |
| Tax Planning Advisor | No list of clients whose returns show planning signals (Q4). Planning happens only when a client asks (Q4). | The user thinks more clients should have paid for planning than did (Q4). Planning conversations get pushed out by busy season or extension season (Q4 or Q5). |
| Capacity Planner | Capacity in hours not known (Q5). Extensions filed to manage the firm's workload (Q5). A hire discussed without an hours figure (Q5). | Overtime, weekend work or missed deadlines last busy season (Q5). |
| Team Adoption Lead | Some people use AI and others do not, with no shared way of working (Q7). No time set aside to learn the tools (Q7). Business licenses bought and not used (Q7). | An AI tool was tried and dropped (Q7). Only the user uses AI, and the team asks the user how (Q7). |
| Quality Controller | No record of who checked AI-assisted work (Q7). WISP not reviewed in the last 12 months, or the user does not know (Q7). | No written rule on which client data can go into AI tools (Q7). Tax return information has gone into an AI tool with no Section 7216 check (Q7). |

Goal points: the goal from question 8 adds 2 points to the seat or seats whose work serves it most directly. Give goal points to two seats at most. Use this guide:

| If the goal is about | Give goal points to |
|---|---|
| Growth, more clients or revenue | Practice Strategist, Offer Advisor |
| Profit, fees, realization or cash | Margin Analyst |
| Busy season, hours, extensions or burnout | Capacity Planner, Workflow Architect |
| Advisory work, tax planning or higher-value work | Tax Planning Advisor, Offer Advisor |
| Getting the team to use AI | Team Adoption Lead, Workflow Architect |
| Client data, risk, review or quality | Quality Controller |
| The owner's own time, or stepping back | Practice Strategist, Capacity Planner |

## Step 4: Pick the board

1. A seat with 3 points or more qualifies.
2. The data rule comes first. If tax return information has gone into an AI tool with no Section 7216 check (Q7), the Quality Controller takes a place on the board, whatever its score. It counts as one of the four places.
3. If three or four seats qualify, those seats are the board.
4. If fewer than three seats qualify, add the highest-scoring other seats until the board has three seats.
5. If more than four seats qualify, fill the places in this order:
   a. The Quality Controller, if step 2 applies.
   b. The qualifying seats with goal points from question 8.
   c. The other qualifying seats, highest score first.
   d. On equal scores, the Offer Advisor and the Tax Planning Advisor give way to the Capacity Planner and the Workflow Architect. A new service needs hours before it needs a price.
   e. On equal scores, the Team Adoption Lead gives way to the Workflow Architect. The firm picks the workflow before it rolls out the tool.
   f. On equal scores, the Practice Strategist gives way to any seat whose first action can start this week, unless the user says revenue has been flat or falling for two years.
   g. If seats are still equal, keep the seat whose first action can use numbers the firm already has. If that does not separate them, ask the user to choose.
6. Every seat that qualified but is not on the board goes into "What we are not doing this quarter".

## Step 5: Confirm the board

Show the user a table: each seat, its score, and the answers that gave it the points. Show the seats that are not on the board, with their scores. Then ask, in one message:

- Is this the right board, or do you want to swap one seat?
- What name goes on the plan, and which Monday does the quarter start? If the user does not say, use the next Monday.

If the user swaps a seat, accept it. Write "Chosen by the owner" in the plan next to that seat. If the user swaps out the Quality Controller after step 2 of Step 4 put it on the board, accept it, and add the data rule to "Assumptions to confirm" as an open risk.

## Step 6: Run the seats

For each seat on the board:

1. Read the seat's file:
   - Practice Strategist: `references/practice-strategist.md`
   - Offer Advisor: `references/offer-advisor.md`
   - Workflow Architect: `references/workflow-architect.md`
   - Margin Analyst: `references/margin-analyst.md`
   - Tax Planning Advisor: `references/tax-planning-advisor.md`
   - Capacity Planner: `references/capacity-planner.md`
   - Team Adoption Lead: `references/team-adoption-lead.md`
   - Quality Controller: `references/quality-controller.md`
2. Follow the method in the file. Do the calculations in code.
3. Choose the seat's actions from the file's list of actions. Fill them with this firm's numbers.
4. Obey the file's "Must not" list.

If a method needs a number you do not have, collect the missing numbers for all the seats and ask for them in one message. If the user does not have a number, use a labeled assumption or leave that step out.

## Step 7: Write the plan

Write the plan in the chat. Use the template between START OF TEMPLATE and END OF TEMPLATE. Keep every section and every column. Write "None" in a section that has nothing in it.

START OF TEMPLATE

# CPA Firm Board: 90-day plan for [firm name]

Quarter: [start date] to [end date], 13 weeks
Prepared: [today's date]
Next CPA Firm Board: week 13, [date]

## The goal

"[The user's answer to question 8, in their own words]"

The number that shows it worked: [measure]. [Value today] today. [Target] by week 13.

## The board this quarter

| Seat | Score | Why it is on the board |
|---|---|---|
| [Seat] | [Score] | [The answers that gave it the points, in a few words] |

## The numbers we are starting from

| Number | Today | Source | Confirmed or assumed |
|---|---|---|---|
| [Number] | [Value] | [User, file, QuickBooks report or calculation] | [Confirmed or Assumed] |

## Seat by seat

### [Seat name]

- The decision: [one sentence: what the firm decides to do this quarter]
- The number to move: [measure], from [value today] to [target] by week [n]
- Owner: [role]
- First action this week: [one action, and the day it happens]

[Repeat for each seat on the board.]

## Weeks 1 to 4

| Week | Action | Seat | Owner | Done when |
|---|---|---|---|---|
| [n] | [Action] | [Seat] | [Role] | [What the owner can show] |

## Weeks 5 to 8

| Week | Action | Seat | Owner | Done when |
|---|---|---|---|---|

## Weeks 9 to 13

| Week | Action | Seat | Owner | Done when |
|---|---|---|---|---|
| 13 | Run the CPA Firm Board again with this plan | All | [Role] | New plan written |

## What we are not doing this quarter

| Not doing | Why not now | Look again |
|---|---|---|
| [Seat or request] | [Reason, with its score if it is a seat] | [Quarter or trigger] |

## Assumptions to confirm

| Assumption | Used for | Confirm or correct |
|---|---|---|
| [Assumption] | [Calculation or action] | [Question for the user] |

## Points for a person to decide

| Point | Why it needs a person | Who decides |
|---|---|---|
| [Client flag, data question or regulatory point] | [One line] | [Role, or the firm's adviser] |

## Workings

[Each calculation as you ran it in code: the inputs, the formula and the result.]

END OF TEMPLATE

Rules for the plan:

- Weeks 1 to 4 start with each seat's first action.
- Put no more than three actions in one week for the same owner.
- During busy season weeks (January to April 15), put no more than one action a week on any role that prepares or reviews returns.
- Week 13 always has the action "Run the CPA Firm Board again with this plan".
- In "What we are not doing this quarter", list every qualifying seat that is not on the board. Add any request from the user that the board does not cover.
- Put every client flag from the Tax Planning Advisor, and every data or regulatory point from the Quality Controller, into "Points for a person to decide".
- Before you send the plan, read each action again. If the action could go into any firm's plan unchanged, rewrite it with this firm's numbers, or remove it.

After the plan, do two things:

1. Ask the user to confirm or correct each item in "Assumptions to confirm". If the user corrects a number, run the calculations again in code and update the plan.
2. Offer to save the plan as a Word document, so the user can bring it back next quarter.

## Using the firm's own QuickBooks

Use this section only if the QuickBooks connector is on.

1. Find the name of the connected company. Ask the user to confirm that it is the firm's own company.
2. If it is a client's company, stop. Tell the user to connect the firm's own company, or to continue without QuickBooks. Never use a client's company data in this review.
3. Only read. Never create, send, update or delete anything in QuickBooks: no invoices, estimates, customers, transactions or payment links. If the user asks you to change something in QuickBooks during the review, say that the review only reads, and continue.
4. Pull these figures for the last 12 months, without sales tax:
   - total fee income, from the profit and loss
   - fees invoiced per customer, from sales by customer
   - A/R today, from the A/R aging summary
   - the customers billed by recurring invoice, if the connector shows them
5. Name the QuickBooks report for each figure. Show the figures in a table. Ask the user to confirm them before question 1.
6. Do not ask the user again for a number you have from QuickBooks.

QuickBooks holds fees and A/R. It does not hold time records, the standard value of time, WIP, write-downs or hours per client. Ask for those from the firm's practice management software.

## Running it again next quarter

Use this section if the user gives you last quarter's CPA Firm Board plan.

1. Read last quarter's plan.
2. For each seat on last quarter's board, ask where the number to move is now. Make this table:

| Seat | Number to move | Start | Target | Now | Hit or missed |
|---|---|---|---|---|---|

3. Ask which actions were done, late or dropped.
4. Ask the nine questions again. Before each question, show the user's answer from last quarter in one line. Ask what has changed.
5. Score the seats again. Add 2 points to each seat that missed its number last quarter.
6. If a seat's number has not moved for two quarters, ask the user why. Record one reason in the plan: nobody owned it, the number was wrong, or the action was wrong.
7. A seat that hit its target can leave the board.
8. Put a section called "Last quarter" at the top of the new plan, with the table from step 2 and the reasons from step 6.
