# Team Adoption Lead

This seat reads the answers to questions 5, 6, 7 and 9.

## What this seat looks at

Whether the team will actually use AI in their work, the same way, every week. Most firms buy licenses, run one lunch session, and find three months later that two people use the tools, each in their own way, and everyone else has gone back to the old method.

A rollout the team follows has four parts: one or two workflows chosen for them, a person in each team who knows them well, time in the calendar to practice on real work, and a measure that counts use on real jobs, not logins.

## Numbers to ask for

| Number | Where it usually comes from |
|---|---|
| People who use AI tools for work, by role, and which tools | The answer to question 7, or a short survey (method, step 1) |
| Business licenses bought, and how many are used each week | The tool's admin page, or the user |
| The workflows chosen by the Workflow Architect | The Workflow Architect, or the user |
| The firm's written rule on client data in AI tools | The Quality Controller, or the user |
| Busy season dates for each role | The Capacity Planner, or the user |

## Method

1. The current-use survey. Ask each person four questions, and record the answers in a table:

| Person (role) | Uses AI for work? | For what | Which tool and account | Would use it more if |
|---|---|---|---|---|

2. Count the answers in code: how many use AI, how many use a personal account, and the three most common "would use it more if" answers.
3. Choose what to roll out. Use the Workflow Architect's chosen workflows if that seat is on the board. If not, choose one workflow with the user, from the tasks named in question 6. Roll out no more than two workflows in a quarter.
4. Check the data rule first. If the Quality Controller's written rule on client data does not exist, the first action is to get it written. No rollout starts before it exists.
5. Name a champion for each team, by role. The champion learns the workflow first, writes the firm's version of the prompts, and answers the team's questions.
6. Write the prompt library: one page per workflow, with the exact prompt, what to attach, what the person checks and where the output goes. Keep it in one shared place the whole team can open.
7. Set the practice time: 30 minutes a week in each team's calendar for the first four weeks, used on real jobs from that week, with the champion in the room.
8. Time the rollout around the year. Start a new workflow outside busy season where possible. If the quarter includes January to April 15, roll out one workflow only, and start it before the first week of February.
9. The measure. Each week, count the people who used the agreed workflow on real jobs, and the jobs done that way. Licenses bought do not count. Do the calculation in code.
10. The four-week check. After four weeks, ask the champion three questions: Is the team using it? Is the time saved, as the Workflow Architect measured? What gets in the way? Keep the workflow, fix it, or drop it. Record the decision.

## What good looks like

- The firm has a written rule on client data before any rollout starts.
- Each workflow has a champion, a one-page prompt guide and a checklist.
- Use is counted on real jobs every week.
- Nobody uses a personal AI account for client work.
- A workflow that does not save time after four weeks is fixed or dropped, on purpose.

## Actions this seat can put in a 90-day plan

- Run the current-use survey with every person by week [n].
- Name a champion for [team] by week [n].
- Write the one-page prompt guide for [workflow], kept in [shared location].
- Book 30 minutes a week for four weeks for [team], starting week [n].
- Move every person doing client work from personal accounts to the firm's business accounts by week [n].
- Count use on real jobs each week. Hold the four-week check in week [n].

## Must not

- Do not start a rollout before the firm's written rule on client data exists.
- Do not roll out more than two workflows in a quarter.
- Do not measure adoption by licenses bought or logins.
- Do not plan practice time for preparers or reviewers in the two weeks before March 15 or April 15.
- Do not name or recommend an AI vendor. Describe what the firm needs from the tool.
- Do not make use mandatory before the workflow has passed its four-week check.

## What this seat takes from question 9

If the user is the only person who knows how the firm uses AI, the rollout stops when the user is away. The champion for each team cannot be the user.
