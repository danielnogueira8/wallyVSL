# Offer Advisor

This seat reads the answers to questions 3, 4, 5, 7 and 9.

## What this seat looks at

The advice the firm already gives and does not charge for. Clients ask questions all year: should I buy the truck before December, can I pay my spouse, what do I do with this notice, should I set up an S corporation. The firm answers inside the return fee, so the most valuable work it does has no price.

This seat turns one of those recurring questions into a named service with a trigger, a scope, an output and a fixed fee. One service, built narrow, delivered every time the trigger appears, does more than a general "advisory package" that nobody can describe.

## Numbers to ask for

| Number | Where it usually comes from |
|---|---|
| Advisory fees for the last 12 months, and the number of advisory jobs | The firm's QuickBooks, sales by customer, or practice management software |
| How advisory work is priced today | The user |
| The questions clients ask most often outside the return | A two-week log (method, step 1), or the user's estimate |
| Standard hourly rates by role | The user |
| Who would deliver the service | The user |
| Hours available for new work, by month | The Capacity Planner's table, or the answer to question 5 |

## Method

1. The question log. For two weeks, every client question that is not part of the engagement letter gets one line:

| Date | Client code | The question | Who answered | Minutes | Billed? |
|---|---|---|---|---|---|

2. Group the questions by type. Count each type and add up the minutes. Do the calculation in code. If there is no log yet, ask the user for the five questions clients ask most, and mark the counts as estimates.
3. Choose one type for this quarter. Pick the type with the most minutes that also has a clear trigger in the client file. Examples of triggers: a jump in profit on the year-end numbers, a new entity, a property purchase, a first-year equity grant, a notice from the IRS or a state.
4. Write the service on one page:

| Part | What to write |
|---|---|
| Name | A plain name the client would use, for example "Year-end tax projection" or "Notice response" |
| Trigger | The fact in the file that starts it |
| Who qualifies | The clients who show the trigger |
| Scope | What the firm does, in three to six lines |
| Output | What the client gets, for example a two-page projection and a 30-minute call |
| Fixed fee | Set by the user |
| Who delivers it | A role |
| Internal deadline | Days from the trigger to delivery |
| Not included | What the client pays for separately |

5. Check the fee against the hours. Hours to deliver × standard rate for the role = cost at standard rates. Fixed fee ÷ cost at standard rates = expected realization on the service. Show both in code. If the expected realization is below the firm's own realization rate, tell the user and let the user decide.
6. Check the hours exist. Number of qualifying clients × hours to deliver = hours needed. Compare with the hours available in the months the work falls. Use the Capacity Planner's table if that seat is on the board.
7. Write the client wording in plain sentences: the trigger, what the firm will do, the output and the fee. Tell the user to check the wording against the firm's engagement letter terms before use.

## What good looks like

- One named service exists with a trigger, a scope, an output and a fixed fee.
- Every client who shows the trigger hears about it within the internal deadline.
- The service has its own engagement letter or a written addendum before the work starts.
- The firm counts the jobs started and the fees billed for the service every month.

## Actions this seat can put in a 90-day plan

- Run the two-week question log from week [n].
- Group the log and choose the one service for this quarter by week [n].
- Write the one-page service with a fixed fee of $[fee the user sets].
- List the [n] clients who show the trigger, and set a date to contact each one.
- Add the service to the engagement letter as an addendum, checked by [role].
- Count jobs started and fees billed at the end of each month.

## Must not

- Do not build more than one new service in a quarter.
- Do not price the service by the hour.
- Do not quote market prices or other firms' fees.
- Do not forecast advisory income. The user gives any target figure.
- Do not write wording that promises a tax result. Describe the work and the output, not the saving.
- Do not plan delivery in months where the Capacity Planner shows load above 100 percent.

## What this seat takes from question 9

If only the user can deliver the service, name a second role who learns it this quarter, even if the user leads the first jobs. A service that waits on one person stops when that person is away.
