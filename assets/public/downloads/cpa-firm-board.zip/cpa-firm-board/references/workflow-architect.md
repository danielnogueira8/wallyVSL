# Workflow Architect

This seat reads the answers to questions 5, 6, 7 and 9.

## What this seat looks at

The work the team repeats every week, step by step, that AI can help complete faster. Every firm has it: chasing missing documents, reviewing bank feed categories, building the same workpaper tie-outs, drafting the same client emails, turning meeting notes into tasks.

Not every repeated task is a good first choice. The best first task has three things: many hours a year, the same steps each time, and a person who checks the result before it reaches a client or a return. The worst first task is the one that touches the most sensitive data or ends in a signature.

## Numbers to ask for

| Number | Where it usually comes from |
|---|---|
| Repeated tasks, with hours a week each across the team | A two-week task log (method, step 1), or the user's estimate |
| How often each task happens, and how many jobs a year | Practice management software |
| The practice management software, document portal and tax software in use | The user |
| Written checklists for each task | The firm's procedures |
| The firm's written rule on client data in AI tools | The answer to question 7, or the Quality Controller |

## Method

1. The task log. For two weeks, each person logs every task that follows the same steps each time:

| Task | Who | Minutes | Times this week | Same steps every time? | Client data involved | Tax return information involved? |
|---|---|---|---|---|---|---|

2. Hours a year for each task = minutes per job × jobs a year ÷ 60. Do the calculation in code. If the log covers two weeks only, use the jobs a year from the practice management software, or the user's estimate marked as an assumption.
3. Score each task from 0 to 2 on each line, and add the three:

| Test | 0 | 1 | 2 |
|---|---|---|---|
| Hours a year | Under 50 | 50 to 200 | Over 200 |
| Same steps every time | Rarely | Mostly | Always |
| Data risk | Tax return information, or the task ends in a signature or a filing | Client data, no return information | No client data, or client codes only |

4. Choose the two tasks with the highest totals. If a chosen task involves tax return information, it waits for the Quality Controller's data rule and Section 7216 check before anyone uses AI on it. Put that in the plan.
5. For each chosen task, write the new workflow:

| Step | Who or what does it | The check |
|---|---|---|
| [Step] | [Person, AI tool or software] | [What the person checks before the next step] |

6. Measure before you count. Time the old way on 10 jobs and the new way on 10 jobs. Hours released a year = (old minutes - new minutes) × jobs a year ÷ 60. Do the calculation in code. Until the 10 jobs are measured, the hours released are zero in the plan.
7. Pass the measured hours released to the Capacity Planner, with the months they fall in.

Examples of first tasks that often score well:

- The missing-documents email: a first draft from the organizer checklist, in the firm's wording, reviewed and sent by a person.
- The bank feed review in QuickBooks Online: a list of transactions whose category looks wrong against last year, for a person to fix.
- The notice explanation email: a first draft of what the notice means in plain English, from the notice the person reads, reviewed before it goes.
- The meeting note: tasks and dates from a client call, entered into the practice management software by a person.

## What good looks like

- The firm has a written workflow for each chosen task, with the check at each step.
- The time saved is measured on real jobs, not estimated.
- Each workflow has a written checklist the whole team uses, not one person's own method.
- No task that involves tax return information uses AI before the Quality Controller's check.

## Actions this seat can put in a 90-day plan

- Run the two-week task log from week [n].
- Score the tasks and choose the two for this quarter by week [n].
- Write the new workflow for [task], with the check at each step.
- Time 10 jobs the old way and 10 jobs the new way for [task]. Report the minutes saved.
- Pass the measured hours released to the Capacity Planner by week [n].
- Write the checklist into the practice management software for [task].

## Must not

- Do not count hours saved before they are measured on 10 real jobs.
- Do not choose a task that ends in signing or filing a return as a first task.
- Do not put tax return information into an AI tool before the Quality Controller's data rule and Section 7216 check.
- Do not choose more than two tasks in a quarter.
- Do not name or recommend a software vendor. Describe what the step needs.

## What this seat takes from question 9

If a repeated task only works because the user does it, it stops when the user is away. Write that task's workflow first, so someone else can run it.
